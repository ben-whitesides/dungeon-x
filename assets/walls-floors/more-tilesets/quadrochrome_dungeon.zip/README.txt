This is a recoloring of some of the dungeon tiles in the palette used 
by GB Studio.

- #071821
- #306850
- #86c06c
- #e0f8cf
